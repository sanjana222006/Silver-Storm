import os
from typing import Optional
import httpx
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

APP_DIR = os.path.dirname(__file__)
STATIC_DIR = os.path.join(APP_DIR, "static")
LIBRETRANSLATE_URL = os.getenv("LIBRETRANSLATE_URL", "https://libretranslate.com/translate").rstrip("/")
LIBRETRANSLATE_API_KEY = os.getenv("LIBRETRANSLATE_API_KEY", "")
ONLINE_FIRST = os.getenv("ONLINE_FIRST", "true").lower() == "true"

app = FastAPI(title="Translingua AI API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "*").split(","),
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

class TranslateRequest(BaseModel):
    text: str = Field(min_length=1, max_length=5000)
    source: str = "auto"
    target: str
    dialect: Optional[str] = None
    tone: Optional[str] = None

class TranslateResponse(BaseModel):
    translated_text: str
    engine: str
    source: str
    target: str

LANGUAGE_CODES = {
    "English": "en", "Telugu": "te", "Hindi": "hi", "Tamil": "ta",
    "Kannada": "kn", "Malayalam": "ml", "Spanish": "es", "French": "fr",
    "Arabic": "ar", "Japanese": "ja", "Portuguese": "pt", "Bengali": "bn",
    "Marathi": "mr", "Urdu": "ur", "German": "de", "Mandarin Chinese": "zh",
    "Auto-detect": "auto", "auto": "auto",
}
def code_for(language: str) -> str:
    return LANGUAGE_CODES.get(language, language.lower())

def translate_local(text: str, source: str, target: str):
    """Return (translation, reason). Uses installed Argos Translate packages."""
    try:
        import argostranslate.translate as argos
        from_code = code_for(source)
        to_code = code_for(target)
        if from_code == "auto":
            # Argos' package selection is more reliable when source is explicit.
            return None, "Offline Argos translation requires an explicit source language."
        result = argos.translate(text, from_code, to_code)
        if not result or result == text:
            return None, "No installed offline language package matched this language pair."
        return result, None
    except ImportError:
        return None, "Offline engine is not installed. Install argostranslate and download language packages."
    except Exception as exc:
        return None, f"Offline engine could not translate this pair: {exc}"

async def translate_online(text: str, source: str, target: str):
    payload = {"q": text, "source": code_for(source), "target": code_for(target), "format": "text"}
    if LIBRETRANSLATE_API_KEY:
        payload["api_key"] = LIBRETRANSLATE_API_KEY
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            response = await client.post(LIBRETRANSLATE_URL, data=payload)
            response.raise_for_status()
            data = response.json()
        translated = data.get("translatedText")
        if not translated:
            raise ValueError("Translation provider returned no translatedText.")
        return translated
    except Exception as exc:
        raise RuntimeError(str(exc)) from exc

@app.get("/api/health")
async def health():
    offline_ready = False
    installed_pairs = []
    try:
        import argostranslate.translate as argos
        offline_ready = True
        installed_pairs = [f"{p.from_code}->{p.to_code}" for p in argos.get_installed_languages()]
    except ImportError:
        pass
    return {"status": "ok", "online_provider": LIBRETRANSLATE_URL, "offline_package_manager_available": offline_ready, "installed_language_codes": installed_pairs}

@app.post("/api/translate", response_model=TranslateResponse)
async def translate(req: TranslateRequest):
    text = req.text.strip()
    if not text:
        raise HTTPException(status_code=422, detail="Text is required.")
    if len(text) > 5000:
        raise HTTPException(status_code=413, detail="Maximum text length is 5000 characters.")
    source, target = req.source, req.target
    if code_for(source) == code_for(target):
        return TranslateResponse(translated_text=text, engine="identity", source=source, target=target)

    errors = []
    if ONLINE_FIRST:
        try:
            out = await translate_online(text, source, target)
            return TranslateResponse(translated_text=out, engine="online LibreTranslate-compatible API", source=source, target=target)
        except Exception as exc:
            errors.append(f"Online: {exc}")
        out, reason = translate_local(text, source, target)
        if out:
            return TranslateResponse(translated_text=out, engine="offline Argos Translate fallback", source=source, target=target)
        errors.append(reason or "Offline translation unavailable.")
    else:
        out, reason = translate_local(text, source, target)
        if out:
            return TranslateResponse(translated_text=out, engine="offline Argos Translate", source=source, target=target)
        errors.append(reason or "Offline translation unavailable.")
        try:
            out = await translate_online(text, source, target)
            return TranslateResponse(translated_text=out, engine="online LibreTranslate-compatible API fallback", source=source, target=target)
        except Exception as exc:
            errors.append(f"Online: {exc}")
    raise HTTPException(status_code=503, detail={
        "message": "No translation engine could handle this request. No fake translation was generated.",
        "errors": errors,
        "hint": "Check online API access and install an offline model for this language pair."
    })

@app.get("/")
async def index():
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
