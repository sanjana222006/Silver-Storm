# Translingua AI — real online + offline translation starter

This is a real, runnable full-stack starter, not a mock translation UI.

## Architecture
- Browser UI: static HTML/CSS/JavaScript.
- API: FastAPI (`POST /api/translate`).
- Online engine: LibreTranslate-compatible HTTP API.
- Offline fallback: Argos Translate models installed in the backend container.
- Speech: browser dictation and browser text-to-speech where supported. These browser features are not guaranteed to work offline.

## 1. Run locally with Docker
Install Docker Desktop, then in this directory:

```bash
cp .env.example .env
docker compose up --build -d
```

Open http://localhost:8000. API health: http://localhost:8000/api/health

Check logs:
```bash
docker compose logs -f translingua
```

## 2. Configure online translation
The default URL is a public LibreTranslate-compatible endpoint; its access, supported languages, rate limits, and API-key requirements can change. For production, choose a provider/instance you trust and set its URL/key in `.env`. Never commit `.env`, expose a key in frontend JavaScript, or use a public demo endpoint for sensitive text.

If the provider requires a key, edit `.env`:
```dotenv
LIBRETRANSLATE_URL=https://your-trusted-instance/translate
LIBRETRANSLATE_API_KEY=your_server_side_key
```
Then restart:
```bash
docker compose up -d --build
```

## 3. Install offline language models
Argos Translate works offline only for language pairs whose model packages are installed. Package availability differs by language pair; do not assume all listed languages work offline.

For a first test, enter the container:
```bash
docker compose exec translingua bash
```
If bash is unavailable, use `sh`. Then run:
```bash
python -c "import argostranslate.package as p; p.update_package_index(); print('\\n'.join(f'{x.from_code} -> {x.to_code}: {x.package_version}' for x in p.get_available_packages()))"
```
Install one exact pair shown by that command (example below is illustrative; verify the package exists before running):
```bash
python -c "import argostranslate.package as p; p.update_package_index(); packages=p.get_available_packages(); pkg=next(x for x in packages if x.from_code=='en' and x.to_code=='es'); p.install_from_path(pkg.download())"
```
Repeat for pairs you need. Some pairs may be supported by pivoting through another language, but this starter does not silently invent pivot routes. Model files installed inside a disposable container are lost when it is recreated. For durable deployment, build a custom image with the required packages preinstalled, or add a persistent writable model volume and an admin-only model installer. Do not expose a public model-download endpoint.

**Important:** Argos packages are not all available for every language. Check package availability before promising offline Telugu or other language pairs.

## 4. Publish it on the internet
Deploy the Docker image to a host that supports Docker (a VPS or a container platform). Use a domain name and HTTPS through the platform's managed TLS or a reverse proxy. Configure these environment variables in the hosting dashboard, not in source control:
- `LIBRETRANSLATE_URL`
- `LIBRETRANSLATE_API_KEY`
- `ONLINE_FIRST=true`

Set request limits and rate limiting at the reverse proxy/platform, restrict access to the API if needed, monitor provider usage, and publish a privacy notice. The included app has a 5,000-character limit but does not implement user accounts, abuse throttling, or persistent history. Do not treat it as production-hardened without those controls.

A public URL cannot be created from this source bundle alone; you must deploy it to a hosting account you control.

## 5. Test the API
```bash
curl -X POST http://localhost:8000/api/translate \
  -H 'Content-Type: application/json' \
  -d '{"text":"Hello, how are you?","source":"English","target":"Spanish"}'
```
Expected successful response contains `translated_text` and `engine`. If both engines fail or the language pair is unavailable, API returns HTTP 503 with diagnostics instead of pretending to translate.

## Limitations
- `dialect` and `tone` are accepted as request metadata, but traditional translation engines may ignore them. For reliable style-controlled translation, add a separate instruction-following language model and evaluate each language/dialect.
- Speech recognition is browser-provided and may send audio to the browser vendor's service. Browser speech synthesis uses voices installed/available on the client.
- Offline text translation requires installed models. Offline speech recognition and offline neural TTS require separate downloaded speech models and additional integration.
